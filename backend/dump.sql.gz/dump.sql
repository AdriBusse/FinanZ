--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1 (Debian 14.1-1.pgdg110+1)
-- Dumped by pg_dump version 14.1 (Debian 14.1-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Users; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Users" (
    id integer NOT NULL,
    username character varying NOT NULL,
    "firstName" character varying,
    "lastName" character varying,
    password character varying NOT NULL,
    email text NOT NULL,
    confirmed boolean DEFAULT false NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "middleName" character varying
);


ALTER TABLE public."Users" OWNER TO admin;

--
-- Name: Users_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."Users_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Users_id_seq" OWNER TO admin;

--
-- Name: Users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."Users_id_seq" OWNED BY public."Users".id;


--
-- Name: etf; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.etf (
    id integer NOT NULL,
    name character varying NOT NULL,
    title character varying NOT NULL,
    symbol character varying NOT NULL,
    isin character varying NOT NULL,
    wkn character varying NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "userId" integer
);


ALTER TABLE public.etf OWNER TO admin;

--
-- Name: etf_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.etf_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.etf_id_seq OWNER TO admin;

--
-- Name: etf_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.etf_id_seq OWNED BY public.etf.id;


--
-- Name: etf_transaction; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.etf_transaction (
    id integer NOT NULL,
    invest double precision DEFAULT '0'::double precision NOT NULL,
    fee double precision DEFAULT '0'::double precision NOT NULL,
    amount double precision DEFAULT '0'::double precision NOT NULL,
    value double precision DEFAULT '0'::double precision NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "userId" integer,
    "etfId" integer
);


ALTER TABLE public.etf_transaction OWNER TO admin;

--
-- Name: etf_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.etf_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.etf_transaction_id_seq OWNER TO admin;

--
-- Name: etf_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.etf_transaction_id_seq OWNED BY public.etf_transaction.id;


--
-- Name: expense; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.expense (
    id integer NOT NULL,
    title character varying NOT NULL,
    currency character varying DEFAULT '€'::character varying,
    archived boolean DEFAULT false NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "deletedAt" timestamp without time zone,
    "userId" integer
);


ALTER TABLE public.expense OWNER TO admin;

--
-- Name: expenseTransaction; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."expenseTransaction" (
    id integer NOT NULL,
    describtion character varying NOT NULL,
    amount double precision DEFAULT '0'::double precision NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "userId" integer,
    "expenseId" integer,
    "categoryId" integer
);


ALTER TABLE public."expenseTransaction" OWNER TO admin;

--
-- Name: expenseTransaction_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."expenseTransaction_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."expenseTransaction_id_seq" OWNER TO admin;

--
-- Name: expenseTransaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."expenseTransaction_id_seq" OWNED BY public."expenseTransaction".id;


--
-- Name: expense_category; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.expense_category (
    id integer NOT NULL,
    name character varying NOT NULL,
    color character varying,
    icon character varying,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "deletedAt" timestamp without time zone,
    "userId" integer
);


ALTER TABLE public.expense_category OWNER TO admin;

--
-- Name: expense_category_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.expense_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.expense_category_id_seq OWNER TO admin;

--
-- Name: expense_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.expense_category_id_seq OWNED BY public.expense_category.id;


--
-- Name: expense_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.expense_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.expense_id_seq OWNER TO admin;

--
-- Name: expense_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.expense_id_seq OWNED BY public.expense.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.migrations OWNER TO admin;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO admin;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: saving_depot; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.saving_depot (
    id integer NOT NULL,
    name character varying NOT NULL,
    short character varying NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "userId" integer
);


ALTER TABLE public.saving_depot OWNER TO admin;

--
-- Name: saving_depot_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.saving_depot_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.saving_depot_id_seq OWNER TO admin;

--
-- Name: saving_depot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.saving_depot_id_seq OWNED BY public.saving_depot.id;


--
-- Name: saving_transaction; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.saving_transaction (
    id integer NOT NULL,
    describtion character varying NOT NULL,
    amount double precision DEFAULT '0'::double precision NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "userId" integer,
    "depotId" integer
);


ALTER TABLE public.saving_transaction OWNER TO admin;

--
-- Name: saving_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.saving_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.saving_transaction_id_seq OWNER TO admin;

--
-- Name: saving_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.saving_transaction_id_seq OWNED BY public.saving_transaction.id;


--
-- Name: typeorm_metadata; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.typeorm_metadata (
    type character varying NOT NULL,
    database character varying,
    schema character varying,
    "table" character varying,
    name character varying,
    value text
);


ALTER TABLE public.typeorm_metadata OWNER TO admin;

--
-- Name: Users id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Users" ALTER COLUMN id SET DEFAULT nextval('public."Users_id_seq"'::regclass);


--
-- Name: etf id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.etf ALTER COLUMN id SET DEFAULT nextval('public.etf_id_seq'::regclass);


--
-- Name: etf_transaction id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.etf_transaction ALTER COLUMN id SET DEFAULT nextval('public.etf_transaction_id_seq'::regclass);


--
-- Name: expense id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.expense ALTER COLUMN id SET DEFAULT nextval('public.expense_id_seq'::regclass);


--
-- Name: expenseTransaction id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."expenseTransaction" ALTER COLUMN id SET DEFAULT nextval('public."expenseTransaction_id_seq"'::regclass);


--
-- Name: expense_category id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.expense_category ALTER COLUMN id SET DEFAULT nextval('public.expense_category_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: saving_depot id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.saving_depot ALTER COLUMN id SET DEFAULT nextval('public.saving_depot_id_seq'::regclass);


--
-- Name: saving_transaction id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.saving_transaction ALTER COLUMN id SET DEFAULT nextval('public.saving_transaction_id_seq'::regclass);


--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Users" (id, username, "firstName", "lastName", password, email, confirmed, "createdAt", "updatedAt", "middleName") FROM stdin;
1	AdriBusse	\N	\N	$2b$12$0oZZ/4v1i/PxPDD6eyiDjODOsTh/6PACBnoS1fvVxItOzcKvQdrYC	adri@mail.com	f	2023-05-27 08:00:40.978409	2023-05-27 08:00:40.978409	\N
\.


--
-- Data for Name: etf; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.etf (id, name, title, symbol, isin, wkn, "createdAt", "updatedAt", "userId") FROM stdin;
\.


--
-- Data for Name: etf_transaction; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.etf_transaction (id, invest, fee, amount, value, "createdAt", "updatedAt", "userId", "etfId") FROM stdin;
\.


--
-- Data for Name: expense; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.expense (id, title, currency, archived, "createdAt", "updatedAt", "deletedAt", "userId") FROM stdin;
1	SecondExpense3	€	f	2023-05-27 08:01:02.176964	2023-05-27 08:01:02.176964	\N	1
2	first	€	f	2023-05-27 08:01:07.057194	2023-05-27 08:01:07.057194	\N	1
3	second	€	f	2023-05-27 08:01:10.454974	2023-05-27 08:01:10.454974	\N	1
\.


--
-- Data for Name: expenseTransaction; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."expenseTransaction" (id, describtion, amount, "createdAt", "updatedAt", "userId", "expenseId", "categoryId") FROM stdin;
\.


--
-- Data for Name: expense_category; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.expense_category (id, name, color, icon, "createdAt", "updatedAt", "deletedAt", "userId") FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.migrations (id, "timestamp", name) FROM stdin;
1	1685174375771	migration1685174375771
2	1685174601072	migration1685174601072
\.


--
-- Data for Name: saving_depot; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.saving_depot (id, name, short, "createdAt", "updatedAt", "userId") FROM stdin;
\.


--
-- Data for Name: saving_transaction; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.saving_transaction (id, describtion, amount, "createdAt", "updatedAt", "userId", "depotId") FROM stdin;
\.


--
-- Data for Name: typeorm_metadata; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.typeorm_metadata (type, database, schema, "table", name, value) FROM stdin;
\.


--
-- Name: Users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."Users_id_seq"', 1, true);


--
-- Name: etf_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.etf_id_seq', 1, false);


--
-- Name: etf_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.etf_transaction_id_seq', 1, false);


--
-- Name: expenseTransaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."expenseTransaction_id_seq"', 1, false);


--
-- Name: expense_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.expense_category_id_seq', 1, false);


--
-- Name: expense_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.expense_id_seq', 3, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.migrations_id_seq', 2, true);


--
-- Name: saving_depot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.saving_depot_id_seq', 1, false);


--
-- Name: saving_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.saving_transaction_id_seq', 1, false);


--
-- Name: saving_depot PK_0276ab985b1e61b63106a1f986f; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.saving_depot
    ADD CONSTRAINT "PK_0276ab985b1e61b63106a1f986f" PRIMARY KEY (id);


--
-- Name: Users PK_16d4f7d636df336db11d87413e3; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "PK_16d4f7d636df336db11d87413e3" PRIMARY KEY (id);


--
-- Name: expense_category PK_478b68a9314d8787fb3763a2298; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.expense_category
    ADD CONSTRAINT "PK_478b68a9314d8787fb3763a2298" PRIMARY KEY (id);


--
-- Name: saving_transaction PK_6028ba1dd83a6da03e8bc1c4bc3; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.saving_transaction
    ADD CONSTRAINT "PK_6028ba1dd83a6da03e8bc1c4bc3" PRIMARY KEY (id);


--
-- Name: expenseTransaction PK_6567149e0f654f59fc801343652; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."expenseTransaction"
    ADD CONSTRAINT "PK_6567149e0f654f59fc801343652" PRIMARY KEY (id);


--
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- Name: expense PK_edd925b450e13ea36197c9590fc; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.expense
    ADD CONSTRAINT "PK_edd925b450e13ea36197c9590fc" PRIMARY KEY (id);


--
-- Name: etf PK_f8ab7ecb7ec6b4079e471ea45ee; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.etf
    ADD CONSTRAINT "PK_f8ab7ecb7ec6b4079e471ea45ee" PRIMARY KEY (id);


--
-- Name: etf_transaction PK_ff1bf2556a311435c66e1ed8d9e; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.etf_transaction
    ADD CONSTRAINT "PK_ff1bf2556a311435c66e1ed8d9e" PRIMARY KEY (id);


--
-- Name: Users UQ_3c3ab3f49a87e6ddb607f3c4945; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "UQ_3c3ab3f49a87e6ddb607f3c4945" UNIQUE (email);


--
-- Name: Users UQ_ffc81a3b97dcbf8e320d5106c0d; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "UQ_ffc81a3b97dcbf8e320d5106c0d" UNIQUE (username);


--
-- Name: etf_transaction FK_05bac749b270b099c59d5b3b07d; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.etf_transaction
    ADD CONSTRAINT "FK_05bac749b270b099c59d5b3b07d" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: expense FK_06e076479515578ab1933ab4375; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.expense
    ADD CONSTRAINT "FK_06e076479515578ab1933ab4375" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: saving_transaction FK_0dc0a913cd047d210f5e9c75a0f; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.saving_transaction
    ADD CONSTRAINT "FK_0dc0a913cd047d210f5e9c75a0f" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: saving_transaction FK_228edcb56ebba2b75d453a212fa; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.saving_transaction
    ADD CONSTRAINT "FK_228edcb56ebba2b75d453a212fa" FOREIGN KEY ("depotId") REFERENCES public.saving_depot(id) ON DELETE CASCADE;


--
-- Name: expenseTransaction FK_31e2c0602d1c643b4b0213d6023; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."expenseTransaction"
    ADD CONSTRAINT "FK_31e2c0602d1c643b4b0213d6023" FOREIGN KEY ("expenseId") REFERENCES public.expense(id) ON DELETE CASCADE;


--
-- Name: etf FK_3b4eee105174eb5aaf5890eeedc; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.etf
    ADD CONSTRAINT "FK_3b4eee105174eb5aaf5890eeedc" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: expense_category FK_793bdeaec528b4a6a238bfff337; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.expense_category
    ADD CONSTRAINT "FK_793bdeaec528b4a6a238bfff337" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: saving_depot FK_876cc35e4b3a85a42f140737635; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.saving_depot
    ADD CONSTRAINT "FK_876cc35e4b3a85a42f140737635" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: expenseTransaction FK_8acf0d84d005f92fb8d3446ced0; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."expenseTransaction"
    ADD CONSTRAINT "FK_8acf0d84d005f92fb8d3446ced0" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: etf_transaction FK_bbefd86bf2b5222b3a82e0e27aa; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.etf_transaction
    ADD CONSTRAINT "FK_bbefd86bf2b5222b3a82e0e27aa" FOREIGN KEY ("etfId") REFERENCES public.etf(id) ON DELETE CASCADE;


--
-- Name: expenseTransaction FK_dfb3d7a39afb5267660408727b2; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."expenseTransaction"
    ADD CONSTRAINT "FK_dfb3d7a39afb5267660408727b2" FOREIGN KEY ("categoryId") REFERENCES public.expense_category(id);


--
-- PostgreSQL database dump complete
--

